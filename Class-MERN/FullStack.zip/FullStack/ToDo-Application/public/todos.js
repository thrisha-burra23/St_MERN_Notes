
let nextId=1;

function Task(taskTitle,taskDescription,isTaskDone){
    this.taskId=nextId++;
    this.taskTitle=taskTitle;
    this.taskDescription=taskDescription;
    this.isTaskDone=isTaskDone;
}


function TodoStore(){
this.todoStore=[];
}

