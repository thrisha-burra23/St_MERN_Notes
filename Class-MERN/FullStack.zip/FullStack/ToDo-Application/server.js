const express=require("express");
const path=require("path");


const app=express();
//middleware-use
app.use(express.static(path.join(__dirname,"public")))




app.get("/welcome",(request,response)=>{
    response.json({
        message:"hii, welcome...."
    })
})

app.get("/",(request,response)=>{
response.sendFile(path.join(__dirname,"public","index.html"))
})

app.listen(3000,()=>{
    console.log("listening...");
});